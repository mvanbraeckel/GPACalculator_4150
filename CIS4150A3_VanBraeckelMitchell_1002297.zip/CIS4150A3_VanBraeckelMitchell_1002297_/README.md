# GPACalculator_4150
(Software Reliability and Testing course A1)
(Software Reliability and Testing course A2)
(Software Reliability and Testing course A3)

Please see my `A1-written.pdf` for my A1 instructions. Please also note that you may need to make the bash scripts executables again after unzipping.

Please see my `A2-written.pdf` for my A2 instructions (uses A1). Please also note that you may need to make the bash scripts executables again after unzipping.

Please see my `A3-README.md` for my A3 instructions (uses A1 and A2, with replaced code as instructed by professor). Please also note that you may need to make the bash scripts executables again after unzipping.