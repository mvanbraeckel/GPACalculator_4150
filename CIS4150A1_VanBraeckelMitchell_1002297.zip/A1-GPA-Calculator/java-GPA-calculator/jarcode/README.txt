
This directory contains the GPA tools for the students.  The code
here will be bundled into a .jar file that the students can use the
access their classes.

There are two classes in the .jar file:

GPAcalculator - state based calculator for GPA by term
GPAconverter - conversion tools to move from percentage or letter
	grade to GPA
